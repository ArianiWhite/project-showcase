# Random Quote Generator

A Pen created on CodePen.

Original URL: [https://codepen.io/ArianiWhite/pen/KwKoQQG](https://codepen.io/ArianiWhite/pen/KwKoQQG).

Here is a code that generate different quotes with a press of a button